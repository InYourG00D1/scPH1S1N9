<?php
$emailku = 'putraandre5678@gmail.com'; // masukin email lu disini coeng -_-
?>