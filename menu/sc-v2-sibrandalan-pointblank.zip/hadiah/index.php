<?php 
session_start();
error_reporting(0);
if($_SESSION['status'] != "Login" && !isset($_SESSION['status']) && empty($_SESSION['status'])) {
	echo "<script type='text/javascript'>document.location='../index.php';</script>";
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PB Indonesia: Item Gratis</title>
<meta name="author" content="">
<meta property="og:type" content="website"/>
<meta property="og:title" content="PB Indonesia: Item Gratis">
<meta property="og:url" content="index.html">
<meta property="og:description" content="Dapatkan hadiah terbaru dari Zepetto. Semua hadiah ini gratis! Ambil hadiah anda sekarang! Kesempatan terbatas!">
<meta property="og:image" content="images/banner.png"/>
<meta name="description" content="Dapatkan hadiah terbaru dari Zepetto. Semua hadiah ini gratis! Ambil hadiah anda sekarang! Kesempatan terbatas!">
<link rel="stylesheet" href="css/raflipedia.css">
<link rel="icon" href="img/icon.png">
<script type="text/javascript" src="js/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="js/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/tab.js"></script>
</head>
<body>

<div class="navbar">
<img src="img/pbbl-white.png">
</div>
</br>
</br>
</br>

<center>
<img class="banner" src="https://pointblank.id/upload/image/20190506/cc241b8d9e2183f3a5bc67065a6eb47e8d62800b5e545f472bea08acedbd18cb.png">
</center>
</br>

<center>
<div id="layer_popup" style="display:none;">
	<p class="dimmed"></p>
	<iframe src="#" height="456" frameborder="0" scrolling="no"></iframe>
</div>
</center>

<center>
<div class="tab-container">
	<div class="tab">
		<div class="kotak">
			<img class="menu" src="img/item.png">
			<div class="container">
				<button onclick="openHero(event, 'item');" id="defaultOpen" class="btn-ambil">LIHAT HADIAH</button>
			</div>
		</div>
		<div class="kotak">
			<img class="menu" src="img/spray.png">
			<div class="container">
				<button onclick="openHero(event, 'spray');" class="btn-ambil">LIHAT HADIAH</button>
			</div>
		</div>
		<div class="kotak">
			<img class="menu" src="img/acc.png">
			<div class="container">
				<button onclick="openHero(event, 'acc');" class="btn-ambil">LIHAT HADIAH</button>
			</div>
		</div>
	</div><!--- tab --->
	</div><!--- tab container --->



<hr class="garis">



<!--- tab konten item --->
<div id="item" class="gallery">
	<div class="kotak">
		<img src="img/1.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/2.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/3.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/4.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/5.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/6.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/7.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/8.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/9.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a1.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a2.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a3.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a4.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a5.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a6.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a7.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a8.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a9.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/a10.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b1.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b2.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b3.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b4.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b5.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b6.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b7.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b8.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b9.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b10.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b11.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b12.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b13.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b14.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b15.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b16.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b17.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b18.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b19.jpg">
		<div class="container">
			<a href="../logout/index.php;"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b20.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b21.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b22.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b23.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b24.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b25.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b26.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b27.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b28.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b29.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/b30.jpg">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/14.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/15.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/16.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/11.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/12.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
</div>
<!--- /tab konten item --->



<!--- tab konten spray --->
<div id="spray" class="gallery">
	<div class="kotak">
		<img src="img/20.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/21.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/22.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/23.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/24.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/25.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
</div>
<!--- /tab konten spray --->



<!--- tab konten acc --->
<div id="acc" class="gallery">
	<div class="kotak">
		<img src="img/10.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/13.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
	<div class="kotak">
		<img src="img/17.png">
		<div class="container">
			<a href="../logout/index.php"><button class="btn-ambil">AMBIL</button></a>
		</div>
	</div>
</div>
<!--- /tab konten acc --->
</center>

</br>
</br>

<script type="text/javascript">
function openHero(evt, heroClass) {
    var i, gallery, tab;
    gallery = document.getElementsByClassName("gallery");
    for (i = 0; i < gallery.length; i++) {
        gallery[i].style.display = "none";
    }
    tab = document.getElementsByClassName("tab");
    for (i = 0; i < tab.length; i++) {
        tab[i].className = tab[i].className.replace(" active", "");
    }
    document.getElementById(heroClass).style.display = "block";
    evt.currentTarget.className += " active";
}
document.getElementById("defaultOpen").click();
</script>

</body>
</html>