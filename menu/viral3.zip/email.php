<!-- TIDAK DI JUAL -->
<?php
$emailku = 'emailkamu-uhuinfo-hehehe@gmail.com';
?>