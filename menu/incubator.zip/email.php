<!-- DETOL SHOP -->
<?php
$emailku = 'jekybarier@gmail.com';
?>