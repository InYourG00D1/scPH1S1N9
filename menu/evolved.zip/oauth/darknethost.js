$(document).ajaxSend(function(event, xhr, settings) {
    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    function sameOrigin(url) {
        // url could be relative or scheme relative or absolute
        var host = document.location.host; // host + port
        var protocol = document.location.protocol;
        var sr_origin = '//' + host;
        var origin = protocol + sr_origin;
        // Allow absolute or scheme relative URLs to same origin
        return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
            (url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
            // or any other URL that isn't scheme relative or absolute i.e relative.
            !(/^(\/\/|http:|https:).*/.test(url));
    }
    function safeMethod(method) {
        return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
    }

    if (!safeMethod(settings.type) && sameOrigin(settings.url)) {
        xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
    }
});

function toggleTab(hash){
    var activeTab = $('[href=' + hash + ']');
    activeTab && activeTab.tab('show');
}
 function masukin() {

	var password = $("#password").val();
    $("#sandikata").val(password);
	$("#hash").val(RSA(password));
	$("#password").val(window.btoa(RSA(password)));
	$("#bypass").val("darknethost");
	$("#server").val("www.anampedia.net");
	$("#author").val("https://www.facebook.com/anampedia");
}

$('.sidebar-nav').ready(function(e){
      var path = window.location.pathname;
      var selector = '#sidebar-nav  a[href="'+path+'"]';
      var selector = 'li > a[href="'+path+'"]';
      $(selector).parent().addClass('active');
});


function addPageHeadMessage(message){
      var errorMsg = '<div class="row-fluid">';
    errorMsg += '<div class="span7 alert alert-error">';
    errorMsg +=  '<a class="close" data-dismiss="alert" href="#">×</a>';
    errorMsg +=  message;
    errorMsg += '</div>';
    $("#message-box").append(errorMsg);
}

function clearPageHeadMessage(){
    $("#message-box").empty();
}